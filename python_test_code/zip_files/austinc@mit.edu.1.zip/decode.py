def decode(ciphertext, out_file):
    print "in decode"
    s = ciphertext[:20]
    f = open(out_file, 'w')
    f.write(s)
    f.close()

